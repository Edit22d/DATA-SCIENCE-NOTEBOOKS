# Question 1(i)
# Write a Python program to find the distance between two coordinate points (x1, y1) and (x2, y2).
x1 = int(input('Enter point x1:\t'))
y1 = int(input('Enter point y2:\t'))
x2 = int(input('Enter point x2:\t'))
y2 = int(input('Enter point y2:\t'))
distance = ( (x1, y1)^2 + (x2, y2)^2)
import math
math.sqrt()
print(f'The distance between two coordinate points is : { distance:,} ')








# Question 1(ii)
# Write a Python program to find maximum between three numbers.
number_one = int(input('Enter number one:\t'))
number_two = int(input('Enter number two:\t'))
number_three = int(input('Enter number three:\t'))
maximum = number_one + number_two + number_three
print(f'The maximum of number_one and number_two and number_three is :{maximum:,}')
    



